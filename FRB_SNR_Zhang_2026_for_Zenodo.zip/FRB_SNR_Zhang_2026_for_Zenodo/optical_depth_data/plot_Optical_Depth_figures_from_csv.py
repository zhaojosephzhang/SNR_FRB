import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# =========================
# Read CSV
# =========================
DATA_DIR = "./"     ##Change by yourself

csv_path = os.path.join(
    DATA_DIR,
    "optical_depth_time_series_11_30Msun_single_binary.csv"
)

df = pd.read_csv(csv_path)

print(df.head())
print(df["region"].unique())
print(df.groupby(["mass_Msun", "model", "region"]).size())


# =========================
# Basic style
# =========================
font_label = {"family": "serif", "size": 20}
font_legend_xsmall = {"family": "serif", "size": 12}
tick_size = 18

model_colors = {
    "single": "#1f77b4",
    "binary": "#ff7f0e",
}

comp_colors = {
    "Full": "#1f77b4",
    "Shocked": "#d62728",
    "Unshocked ejecta": "#2ca02c",
    "Unshocked CSM": "#9467bd",
}


# =========================
# 1. Reproduce shock-region comparison
# =========================
for mass in [11, 30]:

    fig, ax = plt.subplots(figsize=(8, 6))

    for model in ["single", "binary"]:

        sub = df[
            (df["mass_Msun"] == mass)
            & (df["model"] == model)
            & (df["region"] == "shock")
        ].copy()

        if sub.empty:
            continue

        sub = sub.sort_values("time_yr")

        t = sub["time_yr"].to_numpy()
        tau_ff = sub["tau_ff"].to_numpy()
        tau_T = sub["tau_T"].to_numpy()

        c = model_colors[model]
        label_m = fr"{mass} M$_\odot$ {model.capitalize()}"

        ax.plot(t, tau_ff, "-", color=c, label=r"$\tau_{\rm ff}$ " + label_m)
        ax.plot(t, tau_T, "--", color=c, label=r"$\tau_{\rm T}$ " + label_m)

    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("Time [yr]", **font_label)
    ax.set_ylabel("Optical Depth", **font_label)
    ax.grid(True, which="both")
    ax.tick_params(labelsize=tick_size)
    ax.legend(prop=font_legend_xsmall)

    plt.tight_layout()
    plt.savefig(os.path.join(DATA_DIR, f"replot_tau_ff_{mass}Msun_shock_from_csv.png"), dpi=150)
    plt.show()


# =========================
# 2. Reproduce full-region comparison
# =========================
for mass in [11, 30]:

    fig, ax = plt.subplots(figsize=(8, 6))
    t_esc_model = {}

    for model in ["single", "binary"]:

        sub = df[
            (df["mass_Msun"] == mass)
            & (df["model"] == model)
            & (df["region"] == "full_unshocked_ejecta_plus_CSM")
        ].copy()

        if sub.empty:
            continue

        sub = sub.sort_values("time_yr")

        t = sub["time_yr"].to_numpy()
        tau_ff = sub["tau_ff"].to_numpy()
        tau_T = sub["tau_T"].to_numpy()

        c = model_colors[model]

        ax.plot(
            t,
            tau_ff,
            "-",
            color=c,
            label=fr"{mass} M$_\odot$ {model.capitalize()} $\tau_{{\rm ff}}$",
        )

        ax.plot(
            t,
            tau_T,
            "--",
            color=c,
            label=fr"{mass} M$_\odot$ {model.capitalize()} $\tau_{{\rm T}}$",
        )

        tau_tot = tau_ff + tau_T
        idx = np.nanargmin(np.abs(tau_tot - 1.0))
        t_esc_model[model] = t[idx]

    for model in ["single", "binary"]:
        if model not in t_esc_model:
            continue

        t_esc = t_esc_model[model]
        if t_esc > 4:
            ax.axvline(
                x=t_esc,
                color=model_colors[model],
                lw=2,
                ls=":",
                alpha=0.8,
                label=fr"$t_{{\rm esc}}\sim{int(t_esc)}$ yr",
            )

    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("Time [yr]", **font_label)
    ax.set_ylabel("Optical Depth", **font_label)
    ax.grid(True, which="both")
    ax.tick_params(labelsize=tick_size)
    ax.legend(prop=font_legend_xsmall)

    plt.tight_layout()
    plt.savefig(os.path.join(DATA_DIR, f"replot_tau_ff_{mass}Msun_full_comp_from_csv.png"), dpi=150)
    plt.show()


# =========================
# 3. Reproduce component-vs-full 2x2 figure
# =========================
fig, axes = plt.subplots(2, 2, figsize=(12, 9), sharex=True)

for i, mass in enumerate([11, 30]):
    for j, model in enumerate(["single", "binary"]):

        ax = axes[i, j]

        sub = df[
            (df["mass_Msun"] == mass)
            & (df["model"] == model)
            & (df["region"] == "full_unshocked_ejecta_plus_CSM")
        ].copy()

        if sub.empty:
            continue

        sub = sub.sort_values("time_yr")

        t = sub["time_yr"].to_numpy()

        ax.plot(
            t,
            sub["tau_ff"].to_numpy(),
            color=comp_colors["Full"],
            lw=2.2,
            label="Full",
        )

        ax.plot(
            t,
            sub["tau_ff_shocked"].to_numpy(),
            color=comp_colors["Shocked"],
            label="Shocked",
        )

        ax.plot(
            t,
            sub["tau_ff_unshocked_ejecta"].to_numpy(),
            color=comp_colors["Unshocked ejecta"],
            label="Unsh. ejecta",
        )

        ax.plot(
            t,
            sub["tau_ff_unshocked_CSM"].to_numpy(),
            color=comp_colors["Unshocked CSM"],
            label="Unsh. CSM",
        )

        ax.text(
            0.01,
            0.02,
            fr"${mass}\,M_\odot$ {model}",
            transform=ax.transAxes,
            ha="left",
            va="bottom",
            fontsize=12,
            color="0.2",
        )

        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.grid(True, which="both")
        ax.tick_params(labelsize=tick_size)

handles, labels = axes[0, 0].get_legend_handles_labels()
if handles:
    axes[0, 0].legend(handles, labels, prop=font_legend_xsmall, loc="upper right")

axes[1, 0].set_xlabel("Time [yr]", **font_label)
axes[1, 1].set_xlabel("Time [yr]", **font_label)
axes[0, 0].set_ylabel(r"$\tau_{\rm ff}$", **font_label)
axes[1, 0].set_ylabel(r"$\tau_{\rm ff}$", **font_label)

plt.tight_layout()
plt.savefig(os.path.join(DATA_DIR, "replot_tau_components_full_2_2_from_csv.png"), dpi=150)
plt.show()
