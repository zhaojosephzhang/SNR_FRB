# ============================================================
# Reproduce theoretical benchmark DM comparison figures from CSV
# ============================================================

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

DATA_DIR = "./"  ####Change by yourself

CSV_PATH = os.path.join(
    DATA_DIR,
    "DM_theoretical_benchmark_comparison_11_30Msun_single_binary.csv"
)

FIG_DIR = os.path.join(DATA_DIR, "reproduced_figures")
os.makedirs(FIG_DIR, exist_ok=True)

df = pd.read_csv(CSV_PATH)

font_label = {"family": "serif", "size": 20}
font_legend_xxxsmall = {"family": "serif", "size": 8.5}
tick_size = 16

model_colors = {
    "single": "#1f77b4",
    "binary": "#ff7f0e",
}

for mass in sorted(df["mass_Msun"].unique()):
    for channel in ["single", "binary"]:

        sub = df[
            (df["mass_Msun"] == mass)
            & (df["channel"] == channel)
        ].copy()

        if sub.empty:
            continue

        sub = sub.sort_values("time_yr")
        t = sub["time_yr"].to_numpy()

        c_line = model_colors[channel]

        Mej = sub["Mej_Msun"].iloc[0]

        fig, ax = plt.subplots(figsize=(8, 6))

        # Upper limit
        if np.any(np.isfinite(sub["DM_upper_limit_full_ionization_pc_cm3"])):
            ax.plot(
                t,
                sub["DM_upper_limit_full_ionization_pc_cm3"],
                label="Upper limit",
                c="k",
                ls="--",
                linewidth=1.2,
                alpha=0.8
            )

        # Simulation full DM
        ax.plot(
            t,
            sub["DM_simulation_full_pc_cm3"],
            label="Simulation (full region)",
            c=c_line,
            ls="-",
            linewidth=2.2
        )

        # Simulation uncertainty band
        if np.any(np.isfinite(sub["DM_simulation_lower_pc_cm3"])):
            ax.fill_between(
                t,
                sub["DM_simulation_lower_pc_cm3"],
                sub["DM_simulation_upper_pc_cm3"],
                color=c_line,
                alpha=0.05,
                linewidth=0
            )

        # Theoretical benchmarks
        ax.plot(
            t,
            sub["DM_Yang_Zhang_2017_ionized_ejecta_pc_cm3"],
            label="Yang&Zhang17: ionized ejecta",
            linewidth=2.0,
            ls=":"
        )

        ax.plot(
            t,
            sub["DM_Piro_Gaensler_2018_shocked_ionized_pc_cm3"],
            label="Piro&Gaensler18: shocked ionized",
            linewidth=2.0,
            ls=":"
        )

        ax.plot(
            t,
            sub["DM_Piro_Gaensler_2018_wind_case_pc_cm3"],
            label="Piro&Gaensler18: wind case",
            linewidth=2.0,
            ls=":"
        )

        ax.plot(
            t,
            sub["DM_Zhao_2021_wind_SSDW_total_pc_cm3"],
            label="Zhao+21: wind case (SSDW)",
            linewidth=2.0,
            ls=":"
        )

        # FRB horizontal reference levels
        dm_FRB20190520B = sub["DM_FRB20190520B_reference_pc_cm3"].iloc[0]
        dm_FRB20121102 = sub["DM_FRB20121102_reference_pc_cm3"].iloc[0]
        dm_FRB20220529A = sub["DM_FRB20220529A_reference_pc_cm3"].iloc[0]

        ax.axhline(
            y=dm_FRB20190520B,
            c=c_line,
            ls="-.",
            label=rf"FRB 20190520B (~{dm_FRB20190520B:.1f} pc cm$^{{-3}}$)"
        )

        ax.axhline(
            y=dm_FRB20121102,
            c=c_line,
            ls="--",
            label=rf"FRB 20121102 (~{dm_FRB20121102:.1f} pc cm$^{{-3}}$)"
        )

        ax.axhline(
            y=dm_FRB20220529A,
            c=c_line,
            linestyle=(0, (1, 1)),
            label=rf"FRB 20220529A (~{dm_FRB20220529A:.1f} pc cm$^{{-3}}$)"
        )

        ax.text(
            0.01,
            0.01,
            f"${mass}\\,M_\\odot$ {channel.capitalize()} "
            f"(M$_{{\\mathrm{{ej}}}}$={Mej:.2f})",
            transform=ax.transAxes,
            ha="left",
            va="bottom",
            fontsize=12,
            color="0.2"
        )

        ax.set_xlabel("Time [yr]", **font_label)
        ax.set_ylabel("DM [pc cm$^{-3}$]", **font_label)
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.grid(True)
        ax.tick_params(labelsize=tick_size)
        ax.legend(prop=font_legend_xxxsmall, loc="upper right")

        plt.tight_layout()

        outname = f"replot_DM_full_{mass}_{channel}_comparison_with_analytic.png"
        plt.savefig(os.path.join(FIG_DIR, outname), dpi=150)
        plt.show()

        print(f"Saved: {outname}")

print("All reproduced benchmark figures were saved to:")
print(FIG_DIR)
