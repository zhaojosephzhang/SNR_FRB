import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D


# ============================================================
# Paths
# ============================================================

DATA_DIR = "./"  ##Change by yourself

DM_CSV = os.path.join(DATA_DIR, "DM_time_series_11_30Msun_single_binary.csv")
RM_CSV = os.path.join(DATA_DIR, "RM_time_series_11_30Msun_single_binary.csv")

FIG_DIR = os.path.join(DATA_DIR, "reproduced_figures")
os.makedirs(FIG_DIR, exist_ok=True)


# ============================================================
# Read data
# ============================================================

df_dm = pd.read_csv(DM_CSV)
df_rm = pd.read_csv(RM_CSV)

print("Loaded DM data:", DM_CSV)
print("Loaded RM data:", RM_CSV)
print(df_dm.head())
print(df_rm.head())


# ============================================================
# Plot style
# ============================================================

masses = [11, 30]
models = ["single", "binary"]

font_label = {"family": "serif", "size": 20}
font_label_small = {"family": "serif", "size": 17}
font_label_xsmall = {"family": "serif", "size": 15}

font_legend = {"family": "serif", "size": 14}
font_legend_small = {"family": "serif", "size": 12}
font_legend_xsmall = {"family": "serif", "size": 11}
font_legend_xxsmall = {"family": "serif", "size": 10.5}

tick_size = 16

model_colors = {
    "single": "#1f77b4",
    "binary": "#ff7f0e",
}

comp_colors = {
    "Shock": "#d62728",
    "Unshocked": "#2ca02c",
    "CSM": "#9467bd",
    "Full": "#1f77b4",
}


def get_dm_sub(mass, model):
    sub = df_dm[
        (df_dm["mass_Msun"] == mass)
        & (df_dm["model"] == model)
    ].copy()
    return sub.sort_values("time_yr")


def get_rm_sub(mass, model):
    sub = df_rm[
        (df_rm["mass_Msun"] == mass)
        & (df_rm["model"] == model)
    ].copy()
    return sub.sort_values("time_yr")


# ============================================================
# 1. DM components, individual panels
# ============================================================

for m in masses:
    for model in models:

        sub = get_dm_sub(m, model)
        if sub.empty:
            continue

        t = sub["time_yr"].to_numpy()

        plt.figure(figsize=(8, 6))

        plt.plot(
            t,
            sub["DM_full_pc_cm3"],
            label="Full",
            lw=2.2,
            color=comp_colors["Full"],
        )

        plt.plot(
            t,
            sub["DM_shocked_pc_cm3"],
            label="Shocked",
            ls="--",
            color=comp_colors["Shock"],
        )

        plt.plot(
            t,
            sub["DM_unshocked_ejecta_pc_cm3"],
            label="Unsh. ejecta",
            ls="-.",
            color=comp_colors["Unshocked"],
        )

        plt.plot(
            t,
            sub["DM_unshocked_CSM_pc_cm3"],
            label="Unsh. CSM",
            ls=":",
            color=comp_colors["CSM"],
        )

        if (
            "DM_full_lower_pc_cm3" in sub.columns
            and "DM_full_upper_pc_cm3" in sub.columns
            and np.any(np.isfinite(sub["DM_full_lower_pc_cm3"]))
        ):
            plt.fill_between(
                t,
                sub["DM_full_lower_pc_cm3"],
                sub["DM_full_upper_pc_cm3"],
                color=comp_colors["Full"],
                alpha=0.15,
                linewidth=0,
            )

        plt.xlabel("Time [yr]", **font_label)
        plt.ylabel("DM [pc cm$^{-3}$]", **font_label)
        plt.title(
            f"DM Components (Full) - {m} $M_{{\\odot}}$ {model.capitalize()}",
            **font_label_small,
        )
        plt.legend(prop=font_legend)
        plt.yscale("log")
        plt.xscale("log")
        plt.grid(True)
        plt.tick_params(labelsize=tick_size)
        plt.tight_layout()

        plt.savefig(
            os.path.join(FIG_DIR, f"replot_DM_components_full_{m}_{model}.png"),
            dpi=150,
        )
        plt.show()


# ============================================================
# 2. DM components 2x2 figure
# ============================================================

fig, axes = plt.subplots(2, 2, figsize=(12, 9), sharex=True, sharey=True)

time_scaling = {
    "11_single": {"x": 0.05, "y": 0.83, "label": r"$\propto t^{-1.94}$"},
    "11_binary": {"x": 0.05, "y": 0.635, "label": r"$\propto t^{-1.93}$"},
    "30_single": {"x": 0.05, "y": 0.82, "label": r"$\propto t^{-1.83}$"},
    "30_binary": {"x": 0.05, "y": 0.795, "label": r"$\propto t^{-1.84}$"},
}

order_mass = [11, 30]
order_model = ["single", "binary"]

for i, model in enumerate(order_model):
    for j, m in enumerate(order_mass):

        ax = axes[i, j]
        key = f"{m}_{model}"

        sub = get_dm_sub(m, model)
        if sub.empty:
            continue

        t = sub["time_yr"].to_numpy()

        ax.plot(
            t,
            sub["DM_full_pc_cm3"],
            label="Full",
            lw=2.2,
            color=comp_colors["Full"],
        )

        ax.plot(
            t,
            sub["DM_shocked_pc_cm3"],
            label="Shocked",
            ls="--",
            color=comp_colors["Shock"],
        )

        ax.plot(
            t,
            sub["DM_unshocked_ejecta_pc_cm3"],
            label="Unsh. ejecta",
            ls="-.",
            color=comp_colors["Unshocked"],
        )

        ax.plot(
            t,
            sub["DM_unshocked_CSM_pc_cm3"],
            label="Unsh. CSM",
            ls=":",
            color=comp_colors["CSM"],
        )

        if np.any(np.isfinite(sub["DM_full_lower_pc_cm3"])):
            ax.fill_between(
                t,
                sub["DM_full_lower_pc_cm3"],
                sub["DM_full_upper_pc_cm3"],
                color=comp_colors["Full"],
                alpha=0.15,
                linewidth=0,
            )

        if key in time_scaling:
            ax.text(
                time_scaling[key]["x"],
                time_scaling[key]["y"],
                time_scaling[key]["label"],
                transform=ax.transAxes,
                ha="left",
                va="bottom",
                fontsize=14,
                color=comp_colors["Unshocked"],
            )

        ax.text(
            0.97,
            0.95,
            f"${m}\\,M_\\odot$ {model}",
            transform=ax.transAxes,
            ha="right",
            va="top",
            fontsize=12,
            color="0.2",
        )

        ax.set_yscale("log")
        ax.set_xscale("log")
        ax.grid(True)
        ax.tick_params(labelsize=tick_size)

axes[1, 0].set_xlabel("Time [yr]", **font_label)
axes[1, 1].set_xlabel("Time [yr]", **font_label)
axes[0, 0].set_ylabel("DM [pc cm$^{-3}$]", **font_label)
axes[1, 0].set_ylabel("DM [pc cm$^{-3}$]", **font_label)

handles, labels = axes[0, 0].get_legend_handles_labels()
if handles:
    axes[0, 0].legend(handles, labels, prop=font_legend, loc="lower left")

plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, "replot_DM_components_full_2_2.png"), dpi=150)
plt.show()


# ============================================================
# 3. DM mass/model comparison
# ============================================================

plt.figure(figsize=(8, 6))

for m in masses:
    for model in models:

        sub = get_dm_sub(m, model)
        if sub.empty:
            continue

        t = sub["time_yr"].to_numpy()
        dm = sub["DM_full_pc_cm3"].to_numpy()

        label = f"{m} $M_{{\\odot}}$ {model.capitalize()}"
        linestyle = "-" if model == "binary" else "--"

        plt.plot(t, dm, label=label, linestyle=linestyle)

plt.xlabel("Time [yr]", **font_label)
plt.ylabel("DM [pc cm$^{-3}$]", **font_label)
plt.legend(prop=font_legend)
plt.yscale("log")
plt.xscale("log")
plt.grid(True)
plt.tick_params(labelsize=tick_size)
plt.tight_layout()

plt.savefig(os.path.join(FIG_DIR, "replot_DM_mass_model_comparison_full.png"), dpi=150)
plt.show()


# ============================================================
# 4. DM / ne / Delta R figure
# ============================================================

fig, axes = plt.subplots(3, 1, figsize=(8, 12), sharex=True)

for m in masses:
    for model in models:

        sub = get_dm_sub(m, model)
        if sub.empty:
            continue

        t = sub["time_yr"].to_numpy()
        linestyle = "-" if model == "binary" else "--"
        label = f"{m} $M_{{\\odot}}$ {model.capitalize()}"

        axes[0].plot(t, sub["DM_full_pc_cm3"], label=label, linestyle=linestyle)
        axes[1].plot(t, sub["ne_avg_cm3"], label=label, linestyle=linestyle)
        axes[2].plot(t, sub["delta_R_dyn_pc"], label=label, linestyle=linestyle)

axes[0].set_ylabel("DM [pc cm$^{-3}$]", **font_label)
axes[1].set_ylabel(r"$\langle n_e \rangle$ [cm$^{-3}$]", **font_label)
axes[2].set_ylabel(r"$\Delta R_{\rm dyn}$", **font_label)
axes[2].set_xlabel("Time [yr]", **font_label)

for ax in axes:
    ax.set_yscale("log")
    ax.set_xscale("log")
    ax.grid(True)
    ax.tick_params(labelsize=tick_size)
    

axes[0].legend(prop=font_legend)

plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, "replot_DM_ne_DeltaR_vs_time_full.png"), dpi=150)
plt.show()


# ============================================================
# 5. dDM/dt and d2DM/dt2 figures
# ============================================================

d_dm_FRB20190520B = 12.4
d_dm_FRB20121102_late = 3.93
d_dm_FRB20220529A = 0.881

for m in masses:

    fig, axes = plt.subplots(2, 1, figsize=(7, 6), sharex=True)

    for model, c in [("single", "#1f77b4"), ("binary", "#ff7f0e")]:

        sub = get_dm_sub(m, model)
        if sub.empty:
            continue

        t = sub["time_yr"].to_numpy()
        minus_dDM_dt = sub["minus_dDM_dt_pc_cm3_yr"].to_numpy()
        d2DM_dt2 = sub["d2DM_dt2_pc_cm3_yr2"].to_numpy()

        mask = np.isfinite(t) & np.isfinite(minus_dDM_dt) & np.isfinite(d2DM_dt2)
        t = t[mask]
        minus_dDM_dt = minus_dDM_dt[mask]
        d2DM_dt2 = d2DM_dt2[mask]

        if len(t) < 3:
            continue

        axes[0].plot(
            t,
            minus_dDM_dt,
            lw=2.0,
            color=c,
            label=f"{m} $M_{{\\odot}}$ {model}",
        )

        axes[1].plot(
            t,
            d2DM_dt2,
            lw=2.0,
            color=c,
            label=f"{m} $M_{{\\odot}}$ {model}",
        )

        idx_90520 = np.nanargmin(np.abs(minus_dDM_dt - d_dm_FRB20190520B))
        idx_121102_l = np.nanargmin(np.abs(minus_dDM_dt - d_dm_FRB20121102_late))
        idx_220529A = np.nanargmin(np.abs(minus_dDM_dt - d_dm_FRB20220529A))

        t_90520 = t[idx_90520]
        t_121102_l = t[idx_121102_l]
        t_220529A = t[idx_220529A]

        for ax in axes:
            ax.axvline(x=t_90520, c=c, ls=":", alpha=0.9)
            ax.axvline(x=t_121102_l, c=c, ls="--", alpha=0.9)
            ax.axvline(x=t_220529A, c=c, ls="-.", alpha=0.9)

        if np.any(np.isfinite(sub["minus_dDM_dt_lower_pc_cm3_yr"])):
            lower = sub.loc[mask, "minus_dDM_dt_lower_pc_cm3_yr"].to_numpy()
            upper = sub.loc[mask, "minus_dDM_dt_upper_pc_cm3_yr"].to_numpy()

            d2_lower = sub.loc[mask, "d2DM_dt2_lower_pc_cm3_yr2"].to_numpy()
            d2_upper = sub.loc[mask, "d2DM_dt2_upper_pc_cm3_yr2"].to_numpy()

            axes[0].fill_between(t, lower, upper, color=c, alpha=0.12, linewidth=0)
            axes[1].fill_between(t, d2_lower, d2_upper, color=c, alpha=0.12, linewidth=0)

    axes[0].set_ylabel(r"$-$dDM/dt [pc cm$^{-3}$ yr$^{-1}$]", **font_label_xsmall)
    axes[1].set_ylabel(r"d$^2$DM/dt$^2$ [pc cm$^{-3}$ yr$^{-2}$]", **font_label_xsmall)
    axes[1].set_xlabel("Time [yr]", **font_label_small)

    frb_handles = [
        Line2D([0], [0], color="k", ls=":", lw=2, label="FRB 20190520B"),
        Line2D([0], [0], color="k", ls="--", lw=2, label="FRB 20121102 (late)"),
        Line2D([0], [0], color="k", ls="-.", lw=2, label="FRB 20220529A"),
    ]

    for ax in axes:
        ax.grid(True)
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xlim(right=101)
        ax.tick_params(labelsize=tick_size)

    handles, labels = axes[0].get_legend_handles_labels()
    axes[0].legend(
        handles + frb_handles,
        labels + [h.get_label() for h in frb_handles],
        prop=font_legend_xxsmall,
        loc="best",
    )

    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, f"replot_dDM_full_{m}_single_binary.png"), dpi=150)
    plt.show()


# ============================================================
# 6. RM vs time
# ============================================================

for m in masses:

    plt.figure(figsize=(8, 6))

    for model, c in [("single", "#1f77b4"), ("binary", "#ff7f0e")]:

        sub = get_rm_sub(m, model)
        if sub.empty:
            continue

        t = sub["time_yr"].to_numpy()
        rm = sub["RM_rad_m2"].to_numpy()

        plt.plot(
            t,
            rm,
            lw=2.2,
            color=c,
            label=f"{m} $M_{{\\odot}}$ {model.capitalize()}",
        )

        if np.any(np.isfinite(sub["RM_lower_rad_m2"])):
            plt.fill_between(
                t,
                sub["RM_lower_rad_m2"],
                sub["RM_upper_rad_m2"],
                color=c,
                alpha=0.15,
                linewidth=0,
            )

    plt.xlabel("Time [yr]", **font_label)
    plt.ylabel(r"RM [rad m$^{-2}$]", **font_label)
    plt.xscale("log")
    plt.yscale("log")
    plt.grid(True)
    plt.tick_params(labelsize=tick_size)
    plt.legend(prop=font_legend)
    plt.tight_layout()

    plt.savefig(os.path.join(FIG_DIR, f"replot_RM_vs_time_{m}.png"), dpi=150)
    plt.show()


# ============================================================
# 7. RM and B_sh vs time
# ============================================================

for m in masses:

    fig, axes = plt.subplots(2, 1, figsize=(8, 8), sharex=True)

    for model, c in [("single", "#1f77b4"), ("binary", "#ff7f0e")]:

        sub = get_rm_sub(m, model)
        if sub.empty:
            continue

        t = sub["time_yr"].to_numpy()

        axes[0].plot(
            t,
            sub["RM_rad_m2"],
            lw=2.2,
            color=c,
            label=f"{m} $M_{{\\odot}}$ {model.capitalize()}",
        )

        if np.any(np.isfinite(sub["RM_lower_rad_m2"])):
            axes[0].fill_between(
                t,
                sub["RM_lower_rad_m2"],
                sub["RM_upper_rad_m2"],
                color=c,
                alpha=0.15,
                linewidth=0,
            )

        axes[1].plot(
            t,
            sub["B_shocked_G"],
            lw=2.0,
            color=c,
            label=f"{m} $M_{{\\odot}}$ {model.capitalize()}",
        )

        if np.any(np.isfinite(sub["B_shocked_lower_G"])):
            axes[1].fill_between(
                t,
                sub["B_shocked_lower_G"],
                sub["B_shocked_upper_G"],
                color=c,
                alpha=0.15,
                linewidth=0,
            )

    axes[0].set_ylabel(r"RM [rad m$^{-2}$]", **font_label)
    axes[1].set_ylabel(r"$B_{\rm sh}$ [G]", **font_label)
    axes[1].set_xlabel("Time [yr]", **font_label)

    for ax in axes:
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.grid(True)
        ax.tick_params(labelsize=tick_size)

    axes[0].legend(prop=font_legend)
    plt.tight_layout()

    plt.savefig(os.path.join(FIG_DIR, f"replot_RM_B_vs_time_{m}.png"), dpi=150)
    plt.show()


print("All reproduced figures were saved to:")
print(FIG_DIR)